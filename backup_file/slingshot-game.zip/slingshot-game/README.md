# Slingshot Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/liabru/pen/dyOXQv](https://codepen.io/liabru/pen/dyOXQv).

A slingshot game example created with the Matter.js physics engine.

Pull back the rock on the slingshot to fire!

Tutorial in issue 255 of net magazine
http://www.creativebloq.com/net-magazine

More Matter.js examples on CodePen:
http://codepen.io/collection/Fuagy/

For more info on the engine, see:
http://brm.io/matter-js/