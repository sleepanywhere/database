# [game] Copycat

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gthibaud/pen/ryQRYP](https://codepen.io/Gthibaud/pen/ryQRYP).

Little update,
I've updated the visuals during the translation and cleaning of the code :) 
Made with [Diorama](https://gitlab.com/teabo/Diorama)